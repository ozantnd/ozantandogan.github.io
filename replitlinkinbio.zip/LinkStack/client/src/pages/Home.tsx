import { useState } from 'react';
import ProfileCard from '@/components/ProfileCard';
import SocialLinkCard from '@/components/SocialLinkCard';
import AdminPanel from '@/components/AdminPanel';
import ThemeToggle from '@/components/ThemeToggle';

interface SocialLink {
  id: string;
  platform: string;
  username: string;
  url: string;
}

interface Profile {
  name: string;
  bio: string;
}

export default function Home() {
  // todo: remove mock functionality - replace with real data from backend
  const [profile, setProfile] = useState<Profile>({
    name: 'Ozan Tandoğan',
    bio: 'Software Developer'
  });

  const [socialLinks, setSocialLinks] = useState<SocialLink[]>([
    { id: '1', platform: 'instagram', username: 'ozantandogan_', url: 'https://www.instagram.com/ozantandogan_/' },
    { id: '2', platform: 'linkedin', username: 'ozantandogann', url: 'https://www.linkedin.com/in/ozantandogann/' },
  ]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-chart-1 to-chart-2 relative">
      {/* Theme Toggle */}
      <div className="absolute top-4 left-4 z-50">
        <ThemeToggle />
      </div>

      {/* Admin Panel */}
      <AdminPanel
        profile={profile}
        socialLinks={socialLinks}
        onProfileUpdate={setProfile}
        onLinksUpdate={setSocialLinks}
      />

      {/* Main Content */}
      <div className="container max-w-md mx-auto px-4 py-8 space-y-6">
        {/* Profile Section */}
        <ProfileCard 
          name={profile.name}
          bio={profile.bio}
        />

        {/* Social Links Section */}
        <div className="space-y-4" data-testid="social-links-container">
          {socialLinks.map((link) => (
            <SocialLinkCard
              key={link.id}
              platform={link.platform}
              username={link.username}
              url={link.url}
            />
          ))}
        </div>

        {/* Footer */}
        <div className="text-center pt-8">
          <p className="text-sm text-white/70">
            Made with ❤️ using Link in Bio
          </p>
        </div>
      </div>
    </div>
  );
}