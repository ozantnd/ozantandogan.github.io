import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Home } from "lucide-react";
import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-chart-1 to-chart-2 flex items-center justify-center p-4">
      <Card className="max-w-md mx-auto text-center p-8 backdrop-blur-sm bg-card/90">
        <div className="mx-auto h-16 w-16 text-muted-foreground mb-6">
          <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-full h-full">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9.172 16.172a4 4 0 015.656 0M9 12h6m-6-4h6m6 6H3" />
          </svg>
        </div>
        <h1 className="text-2xl font-bold text-foreground mb-2">Page not found</h1>
        <p className="text-muted-foreground mb-6">Sorry, we couldn't find the page you're looking for.</p>
        <Link href="/">
          <Button className="hover-elevate active-elevate-2" data-testid="button-home">
            <Home className="w-4 h-4 mr-2" />
            Go Home
          </Button>
        </Link>
      </Card>
    </div>
  );
}
