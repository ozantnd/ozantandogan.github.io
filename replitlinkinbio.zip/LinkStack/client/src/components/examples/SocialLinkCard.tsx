import SocialLinkCard from '../SocialLinkCard';

export default function SocialLinkCardExample() {
  return (
    <div className="space-y-4 max-w-sm">
      <SocialLinkCard
        platform="instagram"
        username="alexjohnson"
        url="https://instagram.com/alexjohnson"
        onClick={() => console.log('Instagram clicked')}
      />
      <SocialLinkCard
        platform="twitter"
        username="alex_codes"
        url="https://twitter.com/alex_codes"
        onClick={() => console.log('Twitter clicked')}
      />
      <SocialLinkCard
        platform="github"
        username="alexjohnson"
        url="https://github.com/alexjohnson"
        onClick={() => console.log('GitHub clicked')}
      />
    </div>
  );
}