import ProfileCard from '../ProfileCard';

export default function ProfileCardExample() {
  return (
    <ProfileCard
      name="Alex Johnson"
      bio="Digital creator, tech enthusiast, and coffee lover ☕ Sharing my journey in design and development. Let's connect!"
    />
  );
}