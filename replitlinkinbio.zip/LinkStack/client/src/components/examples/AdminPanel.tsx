import { useState } from 'react';
import AdminPanel from '../AdminPanel';

export default function AdminPanelExample() {
  const [profile, setProfile] = useState({
    name: 'Alex Johnson',
    bio: 'Digital creator, tech enthusiast, and coffee lover ☕'
  });

  const [socialLinks, setSocialLinks] = useState([
    { id: '1', platform: 'instagram', username: 'alexjohnson', url: 'https://instagram.com/alexjohnson' },
    { id: '2', platform: 'github', username: 'alexjohnson', url: 'https://github.com/alexjohnson' },
    { id: '3', platform: 'linkedin', username: 'alex-johnson', url: 'https://linkedin.com/in/alex-johnson' },
  ]);

  return (
    <div className="relative">
      <AdminPanel
        profile={profile}
        socialLinks={socialLinks}
        onProfileUpdate={setProfile}
        onLinksUpdate={setSocialLinks}
      />
      <div className="text-center text-muted-foreground text-sm">
        Click the settings icon to edit profile and links
      </div>
    </div>
  );
}