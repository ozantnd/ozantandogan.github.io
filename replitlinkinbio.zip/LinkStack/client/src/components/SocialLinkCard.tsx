import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ExternalLink } from 'lucide-react';
import { SiInstagram, SiX, SiLinkedin, SiTiktok, SiYoutube, SiGithub, SiFacebook, SiTwitch } from 'react-icons/si';

interface SocialLinkCardProps {
  platform: string;
  username: string;
  url: string;
  onClick?: () => void;
}

const platformIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  instagram: SiInstagram,
  twitter: SiX,
  x: SiX,
  linkedin: SiLinkedin,
  tiktok: SiTiktok,
  youtube: SiYoutube,
  github: SiGithub,
  facebook: SiFacebook,
  twitch: SiTwitch,
};

const platformColors: Record<string, string> = {
  instagram: 'from-pink-500 to-purple-600',
  twitter: 'from-blue-400 to-blue-600',
  x: 'from-gray-800 to-black',
  linkedin: 'from-blue-600 to-blue-800',
  tiktok: 'from-black to-red-600',
  youtube: 'from-red-500 to-red-700',
  github: 'from-gray-700 to-gray-900',
  facebook: 'from-blue-500 to-blue-700',
  twitch: 'from-purple-500 to-purple-700',
};

export default function SocialLinkCard({ platform, username, url, onClick }: SocialLinkCardProps) {
  const IconComponent = platformIcons[platform.toLowerCase()] || ExternalLink;
  const gradientColor = platformColors[platform.toLowerCase()] || 'from-chart-1 to-chart-2';
  
  const handleClick = () => {
    if (onClick) {
      onClick();
    } else {
      window.open(url, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <Card className="overflow-hidden hover-elevate active-elevate-2 transition-all duration-200 hover:scale-105">
      <Button
        variant="ghost"
        className="w-full h-auto p-0 rounded-none"
        onClick={handleClick}
        data-testid={`button-social-${platform.toLowerCase()}`}
      >
        <div className={`w-full flex items-center p-4 bg-gradient-to-r ${gradientColor} text-white`}>
          <div className="flex items-center space-x-3 flex-1">
            <IconComponent className="w-6 h-6 flex-shrink-0" />
            <div className="text-left">
              <div className="font-medium text-lg capitalize" data-testid={`text-platform-${platform.toLowerCase()}`}>
                {platform}
              </div>
              <div className="text-sm opacity-90" data-testid={`text-username-${platform.toLowerCase()}`}>
                @{username}
              </div>
            </div>
          </div>
          <ExternalLink className="w-4 h-4 opacity-70" />
        </div>
      </Button>
    </Card>
  );
}