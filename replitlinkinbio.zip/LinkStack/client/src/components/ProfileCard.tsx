import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card } from '@/components/ui/card';
import profilePhoto from '@assets/photo_1758886467479.jpg';

interface ProfileCardProps {
  name: string;
  bio: string;
  avatarUrl?: string;
}

export default function ProfileCard({ name, bio, avatarUrl }: ProfileCardProps) {
  return (
    <Card className="p-6 text-center backdrop-blur-sm bg-card/90 border-card-border shadow-lg">
      <div className="flex flex-col items-center space-y-4">
        <Avatar className="w-24 h-24 ring-2 ring-chart-3/20">
          <AvatarImage src={avatarUrl || profilePhoto} alt={name} />
          <AvatarFallback className="text-xl font-bold">
            {name.split(' ').map(n => n[0]).join('')}
          </AvatarFallback>
        </Avatar>
        
        <div className="space-y-2">
          <h1 className="text-2xl font-bold text-foreground" data-testid="text-profile-name">
            {name}
          </h1>
          <p className="text-base text-muted-foreground max-w-sm" data-testid="text-profile-bio">
            {bio}
          </p>
        </div>
      </div>
    </Card>
  );
}