import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Trash2, Plus, Settings } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

interface SocialLink {
  id: string;
  platform: string;
  username: string;
  url: string;
}

interface Profile {
  name: string;
  bio: string;
}

interface AdminPanelProps {
  profile: Profile;
  socialLinks: SocialLink[];
  onProfileUpdate: (profile: Profile) => void;
  onLinksUpdate: (links: SocialLink[]) => void;
}

const platforms = [
  'instagram', 'twitter', 'x', 'linkedin', 'tiktok', 
  'youtube', 'github', 'facebook', 'twitch'
];

export default function AdminPanel({ 
  profile, 
  socialLinks, 
  onProfileUpdate, 
  onLinksUpdate 
}: AdminPanelProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [editingProfile, setEditingProfile] = useState(profile);
  const [editingLinks, setEditingLinks] = useState(socialLinks);
  const [newLink, setNewLink] = useState({ platform: '', username: '', url: '' });

  const addLink = () => {
    if (newLink.platform && newLink.username && newLink.url) {
      const link: SocialLink = {
        id: Date.now().toString(),
        ...newLink
      };
      setEditingLinks([...editingLinks, link]);
      setNewLink({ platform: '', username: '', url: '' });
      console.log('Added new social link:', link);
    }
  };

  const removeLink = (id: string) => {
    setEditingLinks(editingLinks.filter(link => link.id !== id));
    console.log('Removed social link:', id);
  };

  const saveChanges = () => {
    onProfileUpdate(editingProfile);
    onLinksUpdate(editingLinks);
    setIsOpen(false);
    console.log('Saved changes to profile and links');
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          size="icon"
          className="fixed top-4 right-4 z-50 hover-elevate active-elevate-2"
          data-testid="button-admin-toggle"
        >
          <Settings className="w-4 h-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Profile & Links</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Profile Section */}
          <div className="space-y-4">
            <h3 className="font-medium text-foreground">Profile Information</h3>
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={editingProfile.name}
                onChange={(e) => setEditingProfile({ ...editingProfile, name: e.target.value })}
                data-testid="input-profile-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bio">Bio</Label>
              <Textarea
                id="bio"
                value={editingProfile.bio}
                onChange={(e) => setEditingProfile({ ...editingProfile, bio: e.target.value })}
                rows={3}
                data-testid="input-profile-bio"
              />
            </div>
          </div>

          {/* Social Links Section */}
          <div className="space-y-4">
            <h3 className="font-medium text-foreground">Social Links</h3>
            
            {/* Existing Links */}
            <div className="space-y-2">
              {editingLinks.map((link) => (
                <Card key={link.id} className="p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="font-medium capitalize text-sm">{link.platform}</div>
                      <div className="text-xs text-muted-foreground">@{link.username}</div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeLink(link.id)}
                      className="h-8 w-8 hover-elevate active-elevate-2"
                      data-testid={`button-remove-${link.platform}`}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </Card>
              ))}
            </div>

            {/* Add New Link */}
            <Card className="p-3 space-y-3">
              <div className="space-y-2">
                <Label htmlFor="platform">Platform</Label>
                <Select value={newLink.platform} onValueChange={(value) => setNewLink({ ...newLink, platform: value })}>
                  <SelectTrigger data-testid="select-platform">
                    <SelectValue placeholder="Select platform" />
                  </SelectTrigger>
                  <SelectContent>
                    {platforms.map((platform) => (
                      <SelectItem key={platform} value={platform}>
                        <span className="capitalize">{platform}</span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  placeholder="your_username"
                  value={newLink.username}
                  onChange={(e) => setNewLink({ ...newLink, username: e.target.value })}
                  data-testid="input-username"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="url">URL</Label>
                <Input
                  id="url"
                  placeholder="https://..."
                  value={newLink.url}
                  onChange={(e) => setNewLink({ ...newLink, url: e.target.value })}
                  data-testid="input-url"
                />
              </div>
              
              <Button 
                onClick={addLink} 
                className="w-full"
                disabled={!newLink.platform || !newLink.username || !newLink.url}
                data-testid="button-add-link"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Link
              </Button>
            </Card>
          </div>

          {/* Save Button */}
          <Button onClick={saveChanges} className="w-full" data-testid="button-save-changes">
            Save Changes
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}