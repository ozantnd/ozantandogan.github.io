# Link in Bio App Design Guidelines

## Design Approach
**Reference-Based Approach** - Drawing inspiration from Instagram's clean aesthetic and Linktree's functionality, combined with modern mobile-first design patterns for optimal social sharing experience.

## Core Design Elements

### Color Palette
**Primary Colors:**
- Light mode: 280 8% 15% (deep charcoal)
- Dark mode: 280 5% 95% (soft white)
- Background gradients: 260 60% 65% to 320 45% 75% (purple to pink gradient)

**Accent Colors:**
- Interactive elements: 200 95% 60% (vibrant cyan)
- Success states: 150 80% 50% (emerald green)

### Typography
**Font Stack:** Inter via Google Fonts CDN
- Profile name: font-bold text-2xl
- Bio text: font-normal text-base
- Link titles: font-medium text-lg
- Metadata: font-normal text-sm

### Layout System
**Spacing Primitives:** Tailwind units of 4, 6, and 8 (p-4, m-6, h-8)
- Consistent 24px (p-6) padding for cards
- 32px (h-8) height for touch targets
- 16px (p-4) for tight spacing

### Component Library

**Core Components:**
- **Profile Card**: Centered avatar (96px), name, bio text with subtle background blur
- **Social Link Cards**: Rounded rectangles with platform icons, titles, and subtle shadows
- **Navigation**: Minimal top bar with settings icon
- **Admin Interface**: Simple form controls with floating labels

**Visual Treatments:**
- Card shadows: subtle drop shadows (shadow-lg)
- Hover states: gentle scale (hover:scale-105) and brightness increase
- Border radius: rounded-xl for cards, rounded-full for avatar
- Backdrop blur effects on overlay elements

### Responsive Design
- Mobile-first: Single column layout optimized for 375px+ screens
- Desktop: Maximum 400px width, centered with gradient background
- Touch targets: Minimum 44px height for all interactive elements

## Key Design Principles
1. **Thumb-friendly**: All interactions optimized for one-handed mobile use
2. **Visual hierarchy**: Profile → Bio → Social links in clear priority order  
3. **Platform recognition**: Distinctive icons and brand colors for each social platform
4. **Minimal distraction**: Focus on functionality over decorative elements

## Images
**Profile Avatar**: 96x96px circular placeholder using a random avatar generator API or geometric pattern. Positioned at top-center of the profile card with subtle ring border.

**No hero image required** - the gradient background serves as the visual foundation, keeping focus on the social links and profile information.